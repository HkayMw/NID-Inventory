from model.model import Model

class ContactModel(Model):
    def __init__(self) -> None:
        super().__init__()
        self.table = 'contact'
        
    
    
    