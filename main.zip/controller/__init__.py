# model/__init__.py
# This file can be empty or can contain package initialization code
