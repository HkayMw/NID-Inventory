from model.model import Model

class IdModel(Model):
    def __init__(self) -> None:
        super().__init__()
        self.table = 'id'
        
    
    
    