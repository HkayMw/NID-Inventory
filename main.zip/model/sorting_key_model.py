from model.model import Model


class SortingKeyModel(Model):
    def __init__(self):
        super().__init__()
        self.table = 'sorting_key'